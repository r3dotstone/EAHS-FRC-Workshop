var searchData=
[
  ['getcounts_10',['getCounts',['../class_f_s_m_encoder1.html#a9bfd87445960d00cc7dddfe485ab84e8',1,'FSMEncoder1::getCounts()'],['../class_f_s_m_encoder2.html#a32b0cccb0964ccd62b577d1ac6dce0cf',1,'FSMEncoder2::getCounts()']]],
  ['getcountsandreset_11',['getCountsAndReset',['../class_f_s_m_encoder1.html#a459a54681929821e5eeb59755a204533',1,'FSMEncoder1::getCountsAndReset()'],['../class_f_s_m_encoder2.html#a867b37890f6020bd9ffe8ea4269e6044',1,'FSMEncoder2::getCountsAndReset()']]]
];
